\
import os, time, json, tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation
import traceback

from phidget_reader import ETReader
from model import RoastModel, gas_air_suggestion, target_profile_curve
from storage import export_session_csv, timestamp_slug

APPNAME="RoastLab"
BG="#0b1220"; FG="#f1f5f9"; GLASS="#0f172a"; GRID="#1e293b"; ACC="#38bdf8"

def load_cfg():
    if os.path.exists("config.json"):
        try:
            return json.load(open("config.json","r",encoding="utf-8"))
        except Exception:
            pass
    return {"offset_c":0.0,"scale_pct":100.0,"sample_hz":2.0}

CFG = load_cfg()

class S:
    running=False; t0=None
    samples=[]; events=[]; gas=5; air=5; set_temp=0
    meta={"origin":"","density":"","moisture":"","charge_mass_g":"","process":"lavado","brewTarget":"espresso"}
    reader=None; model=None
    ch=0; tc="K"; force_sim=False; force_phidget=False
    input_is_f=False
    show_f=False

def apply_cal(et_c):
    et = (et_c * (CFG["scale_pct"]/100.0)) + CFG["offset_c"]
    return et

S.reader = ETReader(sample_hz=CFG["sample_hz"], channel=S.ch, thermocouple_type=S.tc, force_sim=S.force_sim, force_phidget=S.force_phidget)
S.model = RoastModel(alpha=0.12)

# ================= UI ROOT / MENU ==================
root=tk.Tk()
root.title(APPNAME)
root.configure(bg=BG)
root.geometry("1200x800")

st=ttk.Style(root); st.theme_use("clam")
st.configure("TLabel", background=BG, foreground=FG, font=("Segoe UI", 11))
st.configure("TFrame", background=BG)
st.configure("TButton", background=GLASS, foreground=FG, borderwidth=0, padding=8, font=("Segoe UI Semibold", 11))
st.map("TButton", background=[('active','#172136')])
st.configure("TEntry", fieldbackground="#0f1627", foreground=FG, insertcolor=FG)
st.configure("TSpinbox", fieldbackground="#0f1627", foreground=FG, arrowsize=14)
st.configure("TCombobox", fieldbackground="#0f1627", foreground=FG)

menubar=tk.Menu(root, tearoff=0)
m_file=tk.Menu(menubar, tearoff=0)
def do_new():
    reset_session()
m_file.add_command(label="Nuevo", command=do_new)
def do_export():
    export_all()
m_file.add_command(label="Exportar CSV/PNG", command=do_export)
m_file.add_separator()
m_file.add_command(label="Salir", command=lambda: (S.reader.stop(), root.destroy()))
menubar.add_cascade(label="Archivo", menu=m_file)

m_conf=tk.Menu(menubar, tearoff=0)
def open_calib_1(): wizard_one_point()
def open_calib_2(): wizard_two_points()
m_conf.add_command(label="Calibración 1 punto", command=open_calib_1)
m_conf.add_command(label="Calibración 2 puntos", command=open_calib_2)
def reconf(): reconnect_reader()
m_conf.add_separator()
m_conf.add_command(label="Reconectar lector", command=reconf)
menubar.add_cascade(label="Configuración", menu=m_conf)

m_view=tk.Menu(menubar, tearoff=0)
def toggle_f():
    showf.set(not showf.get())
m_view.add_checkbutton(label="Mostrar °F", command=toggle_f)
menubar.add_cascade(label="Vista", menu=m_view)

m_help=tk.Menu(menubar, tearoff=0)
def about():
    messagebox.showinfo("RoastLab", "RoastLab — MVP\nUI y perfil objetivo dinámico.\nReemplaza logo.png para mostrar tu marca.")
m_help.add_command(label="Acerca de RoastLab", command=about)
menubar.add_cascade(label="Ayuda", menu=m_help)
root.config(menu=menubar)

# =========== BANNER / LOGO BAR ===========
banner=ttk.Frame(root); banner.pack(fill="x", padx=12, pady=8)
# Logo
logo_path="logo.png"
if os.path.exists(logo_path):
    try:
        from PIL import Image, ImageTk
        img = Image.open(logo_path).resize((120,40))
        logo_img = ImageTk.PhotoImage(img)
        logo_label = tk.Label(banner, image=logo_img, bg=BG)
        logo_label.pack(side="left")
    except Exception:
        ttk.Label(banner, text="ROASTLAB", font=("Segoe UI Black", 20)).pack(side="left")
else:
    ttk.Label(banner, text="ROASTLAB", font=("Segoe UI Black", 20)).pack(side="left")

status=tk.Canvas(banner,width=14,height=14,highlightthickness=0,bg=BG); status.pack(side="left", padx=(12,0))
DOT=status.create_oval(1,1,13,13,fill="#ef4444",outline="")
RUNVAR=tk.StringVar(value="RUN: False"); ttk.Label(banner,textvariable=RUNVAR,font=("Segoe UI Semibold", 12)).pack(side="left", padx=(6,12))

ETVAR=tk.StringVar(value="ET —.— °C"); ttk.Label(banner,textvariable=ETVAR,font=("Segoe UI",22,"bold")).pack(side="left",padx=10)
src_var=tk.StringVar(value="Fuente: —"); ttk.Label(banner,textvariable=src_var).pack(side="left", padx=(10,0))
raw_var=tk.StringVar(value="RAW: —  |  FILT: —"); ttk.Label(banner,textvariable=raw_var).pack(side="left", padx=(10,0))
count_var=tk.StringVar(value="Muestras: 0"); ttk.Label(banner,textvariable=count_var).pack(side="left", padx=(10,0))

# =========== CONTROLES SUPERIORES ===========
top=ttk.Frame(root); top.pack(fill="x", padx=12, pady=4)
# Device
ttk.Label(top,text="Canal").pack(side="left",padx=(6,4))
spin_ch=ttk.Spinbox(top,from_=0,to=3,width=4); spin_ch.set(S.ch); spin_ch.pack(side="left")
ttk.Label(top,text="TC").pack(side="left",padx=(8,4))
tc=ttk.Combobox(top, values=["K","J","E","T","N","S","R","B"], width=4); tc.set(S.tc); tc.pack(side="left")
# Flags
sim_var=tk.BooleanVar(value=S.force_sim); ttk.Checkbutton(top, text="Simulador", variable=sim_var).pack(side="left", padx=(12,6))
inputf_var=tk.BooleanVar(value=S.input_is_f); ttk.Checkbutton(top, text="Entrada °F→°C", variable=inputf_var).pack(side="left", padx=(6,6))
force_ph=tk.BooleanVar(value=S.force_phidget); ttk.Checkbutton(top, text="Forzar Phidget", variable=force_ph).pack(side="left", padx=(6,6))
showf=tk.BooleanVar(value=S.show_f); ttk.Checkbutton(top, text="Mostrar °F", variable=showf).pack(side="left", padx=(6,6))
# Sample rate
ttk.Label(top,text="Hz").pack(side="left",padx=(12,4))
rate=ttk.Spinbox(top, from_=0.5, to=10.0, increment=0.5, width=6)
rate.set(CFG["sample_hz"]); rate.pack(side="left")
# Perfil
proc=ttk.Combobox(top, values=["natural","honey","anaerobico","levadura","lavado"], width=12); proc.set(S.meta["process"]); proc.pack(side="left", padx=(12,0))
brew=ttk.Combobox(top, values=["espresso","filter","both"], width=10); brew.set(S.meta["brewTarget"]); brew.pack(side="left")
# Controles de proceso
for lbl, var, rng in [("Gas",(1,10)),("Aire",(1,10)),("Set°",(0,300))]:
    ttk.Label(top, text=lbl).pack(side="left", padx=(12,4))
    sb=ttk.Spinbox(top, from_=rng[0], to=rng[1], width=6); sb.pack(side="left")
    if lbl=="Gas": gas=sb; gas.set(S.gas)
    if lbl=="Aire": air=sb; air.set(S.air)
    if lbl=="Set°": setv=sb; setv.set(S.set_temp)

# Meta
for lbl in [("Origen",18),("Densidad",12),("Humedad",10)]:
    ttk.Label(top,text=lbl[0]).pack(side="left",padx=(12,4))
    e=ttk.Entry(top,width=lbl[1]); e.pack(side="left")
    if lbl[0]=="Origen": origin=e
    if lbl[0]=="Densidad": density=e
    if lbl[0]=="Humedad": moist=e

# =========== BOTONES Y ESTADO ===========
btns=ttk.Frame(root); btns.pack(fill="x", padx=12, pady=6)
def annotate_event(name, t, temp_c):
    v=ax1.axvline(t, color="#f87171", linestyle="--", linewidth=1.2, alpha=0.9)
    marker=ax1.plot(t, temp_c, marker="o", color="#f87171", markersize=5)[0]
    text=ax1.text(t, temp_c+3, f"{name}\\n{t:.0f}s @ {temp_c:.1f}°C", color=FG,
                  bbox=dict(boxstyle="round,pad=0.25", fc=GLASS, ec=GRID, alpha=0.9),
                  ha="left", va="bottom", fontsize=10)
    event_artists.append((v,marker,text))
def log_event(n):
    t=0.0 if not S.t0 else time.time()-S.t0
    bt=S.model.bt_hist[-1] if S.model.bt_hist else None
    et=current_et_c()
    temp = bt if (bt is not None and bt==bt) else et
    S.events.append({"event":n,"t_sec":round(t,2),"temp_c":round(temp,1)})
    annotate_event(n, t, temp)
for name in ["CHARGE","TP","DRY_END","1C","2C","DROP"]:
    ttk.Button(btns, text=name, command=lambda n=name: log_event(n)).pack(side="left", padx=4)

def export_all():
    if not S.samples: messagebox.showwarning("Export","No hay muestras"); return
    base=filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"roast-{timestamp_slug()}")
    if not base: return
    meta=S.meta|{"events_count":len(S.events), "offset_c":CFG["offset_c"], "scale_pct":CFG["scale_pct"]}
    fig.savefig(base.replace(".csv","")+".plot.png", dpi=180, facecolor=BG, bbox_inches="tight")
    export_session_csv(base, S.samples, S.events, meta)
    messagebox.showinfo("Export","CSV/PNG exportados.")
ttk.Button(btns, text="Export CSV/PNG", command=export_all).pack(side="right", padx=4)

# Calibración rápida
cal=ttk.Frame(root); cal.pack(fill="x", padx=12, pady=4)
off_var=tk.StringVar(value=str(CFG["offset_c"])); sca_var=tk.StringVar(value=str(CFG["scale_pct"]))
for lbl, var in [("Offset (°C)", off_var), ("Scale (%)", sca_var)]:
    ttk.Label(cal,text=lbl).pack(side="left"); ttk.Entry(cal,textvariable=var,width=8).pack(side="left",padx=6)
def apply_calibration():
    try:
        CFG["offset_c"]=float(off_var.get())
        CFG["scale_pct"]=float(sca_var.get())
        json.dump(CFG, open("config.json","w",encoding="utf-8"), indent=2)
        messagebox.showinfo("Calibración","Guardado en config.json")
    except Exception as e:
        messagebox.showerror("Calibración", f"Error: {e}")
ttk.Button(cal,text="Aplicar calib", command=apply_calibration).pack(side="left", padx=10)
ttk.Button(cal,text="Calib 1 punto", command=lambda: wizard_one_point()).pack(side="left", padx=6)
ttk.Button(cal,text="Calib 2 puntos", command=lambda: wizard_two_points()).pack(side="left", padx=6)

# Control buttons
ctrl=ttk.Frame(root); ctrl.pack(fill="x", padx=12, pady=6)
def start_run():
    try:
        S.running=True; RUNVAR.set("RUN: True")
        if S.t0 is None: S.t0=time.time()
        log("Start OK")
    except Exception as e:
        log("Start ERROR: "+str(e))
def stop_run():
    S.running=False; RUNVAR.set("RUN: False"); log("Stop")
def reset_session():
    S.running=False; RUNVAR.set("RUN: False")
    S.samples.clear(); S.events.clear()
    S.model.reset(); redraw_empty()
    S.t0=None; eta1.config(text="ETA 1C: —"); etad.config(text="ETA Drop: —"); sugg.config(text="Sugerencia: —")
    events_list.delete(0, "end")
    log("Reset")
def reconnect_reader():
    try: S.reader.stop()
    except: pass
    try:
        hz=float(rate.get()); CFG["sample_hz"]=hz; json.dump(CFG, open("config.json","w",encoding="utf-8"), indent=2)
    except: pass
    S.reader = ETReader(sample_hz=CFG["sample_hz"], channel=int(spin_ch.get()), thermocouple_type=tc.get(),
                        force_sim=sim_var.get(), force_phidget=force_ph.get())
    S.reader.start()
    log(f"Phidget reiniciado (canal={spin_ch.get()}, TC={tc.get()}, sim={sim_var.get()}, forzar={force_ph.get()}, {CFG['sample_hz']} Hz)")
def test_read():
    try:
        raw = S.reader.raw_c
        filt = S.reader.et_c
        messagebox.showinfo("Test lectura", f"Fuente={S.reader.source}\\nRAW={raw:.2f}°C\\nFiltrado={filt:.2f}°C\\nOK={S.reader.ok}\\nAviso={S.reader.warn or '—'}")
    except Exception as e:
        messagebox.showerror("Test lectura", f"Error: {e}")

for lbl, fn in [("Start", start_run), ("Stop (Pausa)", stop_run), ("Reset", reset_session), ("Reconectar lector", reconnect_reader), ("Test lectura", test_read)]:
    ttk.Button(ctrl, text=lbl, command=fn).pack(side="left", padx=6)

footer=ttk.Frame(root); footer.pack(fill="x", padx=12, pady=4)
eta1=ttk.Label(footer,text="ETA 1C: —", font=("Segoe UI", 11)); eta1.pack(side="left",padx=8)
etad=ttk.Label(footer,text="ETA Drop: —", font=("Segoe UI", 11)); etad.pack(side="left",padx=8)
sugg=ttk.Label(footer,text="Sugerencia: —", font=("Segoe UI", 11)); sugg.pack(side="left",padx=8)

# =========== LAYOUT PRINCIPAL: GRAFICOS + SIDEBAR EVENTOS ===========
main=ttk.Frame(root); main.pack(fill="both", expand=True, padx=8, pady=8)
left=ttk.Frame(main); left.pack(side="left", fill="both", expand=True)
right=ttk.Frame(main, width=260); right.pack(side="right", fill="y")

# Eventos panel
ttk.Label(right, text="Eventos").pack(anchor="w", padx=6, pady=(4,2))
events_list=tk.Listbox(right, height=20, bg="#0f1627", fg=FG, selectbackground="#334155")
events_list.pack(fill="both", expand=True, padx=6, pady=4)
def add_event_to_list(ev):
    events_list.insert("end", f"{ev['event']} — {ev['t_sec']}s @ {ev['temp_c']}°C")
def remove_selected_event():
    sel = events_list.curselection()
    if not sel: return
    idx = sel[0]
    try:
        events_list.delete(idx)
        if idx < len(S.events):
            S.events.pop(idx)
    except Exception: pass
ttk.Button(right, text="Eliminar seleccionado", command=remove_selected_event).pack(padx=6, pady=6)

# ======= PLOTS =======
plt.rcParams.update({
    "axes.titlesize": 14, "axes.labelsize": 12, "xtick.labelsize": 12, "ytick.labelsize": 12,
    "font.family": "Segoe UI",
})
fig,(ax1,ax2)=plt.subplots(2,1,figsize=(11.5,7.8),dpi=110, sharex=True)
fig.patch.set_facecolor(BG)
for ax in (ax1,ax2):
    ax.set_facecolor(BG); ax.tick_params(colors=FG,labelsize=12)
    for sp in ax.spines.values(): sp.set_color(GRID)
    ax.grid(True,color=GRID,alpha=0.35,linewidth=0.7)
ax1.set_title("Temperaturas (ET, BT_est, Set, BT_objetivo, BT_pred)", color=FG)
ax1.set_ylabel("°C", color=FG)
ax2.set_title("RoR (actual vs objetivo)", color=FG)
ax2.set_xlabel("Tiempo (s)", color=FG)
ax2.set_ylabel("°C/min", color=FG)

# Series
ln_et,=ax1.plot([],[],label="ET",linewidth=2.6)
ln_bt,=ax1.plot([],[],label="BT_est",linewidth=2.6)
ln_bt_t,=ax1.plot([],[],label="BT_objetivo",linewidth=2.0,linestyle="--")
ln_bt_pred,=ax1.plot([],[],label="BT_pred (2–3 min)",linewidth=1.8,linestyle=":")
ln_set,=ax1.plot([],[],label="Set",linewidth=1.6,linestyle="--")
ax1.legend(facecolor=BG, labelcolor=FG, edgecolor=GRID, loc="upper left", fontsize=10)

ln_ror,=ax2.plot([],[],label="RoR",linewidth=2.4)
ln_ror_t,=ax2.plot([],[],label="RoR_objetivo",linewidth=2.0,linestyle="--")
ax2.legend(facecolor=BG, labelcolor=FG, edgecolor=GRID, loc="upper left", fontsize=10)

# Apply line colors (after creation so it works on Matplotlib defaults)
ln_et.set_color("#60a5fa")
ln_bt.set_color("#f59e0b")
ln_bt_t.set_color("#34d399")
ln_bt_pred.set_color("#f472b6")
ln_set.set_color("#94a3b8")
ln_ror.set_color("#a3e635")
ln_ror_t.set_color("#ef4444")

canvas=FigureCanvasTkAgg(fig, master=left); canvas.get_tk_widget().pack(fill="both",expand=True,padx=6,pady=6)
event_artists=[]

# ======= CONSOLA DEBUG =======
dbg=ttk.Frame(left); dbg.pack(fill="x", padx=6, pady=(0,6))
ttk.Label(dbg, text="Consola").pack(anchor="w")
txt=tk.Text(dbg, height=6, bg="#0f1627", fg="#dde2eb")
txt.pack(fill="both", expand=False)
def log(msg):
    try:
        txt.insert("end", time.strftime("[%H:%M:%S] ") + msg + "\\n")
        txt.see("end")
    except: pass

def redraw_empty():
    for arts in event_artists:
        for a in arts: 
            try: a.remove()
            except Exception: pass
    event_artists.clear()
    for ln in (ln_et, ln_bt, ln_bt_t, ln_bt_pred, ln_set, ln_ror, ln_ror_t):
        ln.set_data([],[])
    canvas.draw_idle()

def current_et_c():
    et=S.reader.et_c
    if et==et and inputf_var.get():
        et = (et - 32.0) * (5.0/9.0)
    et = (et * (CFG["scale_pct"]/100.0)) + CFG["offset_c"]
    if showf.get():
        ETVAR.set(f"ET {et*9/5+32:.1f} °F")
    else:
        ETVAR.set(f"ET {et:.1f} °C")
    return et

def push_meta(*_):
    S.meta["process"]=proc.get(); S.meta["brewTarget"]=brew.get()
    try: S.gas=int(gas.get()); S.air=int(air.get()); S.set_temp=int(setv.get())
    except: pass
    S.meta["origin"]=origin.get(); S.meta["density"]=density.get(); S.meta["moisture"]=moist.get()
for w in [proc,brew,gas,air,setv,origin,density,moist]:
    if hasattr(w,"bind"): w.bind("<<ComboboxSelected>>", push_meta)

S.reader.start()
log("Lector iniciado")

import json as _json
def compute_targets(t_array, process, brew):
    # Produce BT_target y RoR_target dinámicos sobre el vector de tiempos
    try:
        prof=_json.load(open("profiles.json","r",encoding="utf-8"))[process][brew]
        ror_start=float(prof["rorStart"]); ror_end=float(prof["rorEnd"])
        firstC=float(prof["firstCrackBT"]); dropBT=float(prof["dropBT"])
        alpha=float(prof["alpha"])
    except Exception:
        ror_start,ror_end,firstC,dropBT,alpha = 11.0,3.0,196.0,205.0,0.12
    bt_t=[]; ror_t=[]
    for t in t_array:
        bt, rr = target_profile_curve(t, firstC, dropBT, ror_start=ror_start, ror_end=ror_end)
        bt_t.append(bt); ror_t.append(rr)
    import numpy as _np
    return _np.array(bt_t), _np.array(ror_t), firstC, dropBT, alpha

def predict_bt_future(model, horizon_sec=180, step=1.0):
    # Proyección simple: aplica RoR actual decreciendo levemente hacia ror_end nominal
    if not model.bt_hist or not model.t_hist:
        import numpy as _np
        return _np.array([]), _np.array([])
    t0 = model.t_hist[-1]; bt0 = model.bt_hist[-1]
    # estima ror actual:
    if len(model.bt_hist)>=3:
        ror_now = (model.bt_hist[-1]-model.bt_hist[-3])/(model.t_hist[-1]-model.t_hist[-3]+1e-6)*60.0
    else:
        ror_now = 6.0
    ts=[]; bts=[]
    r = ror_now
    for k in range(1, int(horizon_sec/step)+1):
        t = t0 + k*step
        # drift suave hacia 3.5 °C/min
        r = r*0.995 + 3.5*0.005
        bt0 = bt0 + (r/60.0)*step
        ts.append(t); bts.append(bt0)
    import numpy as _np
    return _np.array(ts), _np.array(bts)

def animate(_):
    try:
        et_raw = S.reader.raw_c; et_filt = S.reader.et_c
        src_var.set(f"Fuente: {S.reader.source}")
        try: raw_var.set(f"RAW: {et_raw:.2f} | FILT: {et_filt:.2f}")
        except: pass

        ok=S.reader.ok
        status.itemconfig(DOT, fill=("#22c55e" if ok else "#ef4444"))

        now=time.time()
        if S.t0 is None: S.t0=now
        t=now-S.t0

        et=current_et_c()

        if not S.samples:
            S.samples.append({"t_sec":0.0,"et_c":et if et==et else np.nan,"bt_est_c":np.nan,"ror":np.nan,"gas":S.gas,"air":S.air,"set_temp":S.set_temp})
        else:
            if S.running:
                bt, ror = S.model.step(t, et if et==et else (S.model.bt_hist[-1] if S.model.bt_hist else np.nan))
                S.samples.append({"t_sec":round(t,2),"et_c":round(et,2) if et==et else np.nan,"bt_est_c":round(bt,2),
                                  "ror":round(ror if isinstance(ror,float) else 0.0,3),"gas":S.gas,"air":S.air,"set_temp":S.set_temp})
            else:
                last=S.samples[-1]; last["et_c"]=round(et,2) if et==et else np.nan

        # Construir curvas
        import numpy as _np
        t_arr=_np.array([s["t_sec"] for s in S.samples])
        et_arr=_np.array([s["et_c"] for s in S.samples])
        bt_arr=_np.array([s.get("bt_est_c",_np.nan) for s in S.samples])
        ror_arr=_np.array([s.get("ror",_np.nan) for s in S.samples])

        bt_t, ror_t, firstC, dropBT, alpha = compute_targets(t_arr, S.meta["process"], S.meta["brewTarget"])
        S.model.alpha = alpha

        # Predicción BT a 3 min
        t_pred, bt_pred = predict_bt_future(S.model, horizon_sec=180, step=max(1.0, 1.0/ max(0.2, float(CFG["sample_hz"]))))

        # Asignar datos a series
        ln_et.set_data(t_arr, et_arr); ln_bt.set_data(t_arr, bt_arr); ln_set.set_data(t_arr, _np.full_like(t_arr, S.set_temp))
        ln_bt_t.set_data(t_arr, bt_t)
        if t_pred.size>0:
            ln_bt_pred.set_data(t_pred, bt_pred)
        else:
            ln_bt_pred.set_data([],[])

        ln_ror.set_data(t_arr, ror_arr); ln_ror_t.set_data(t_arr, ror_t)

        # Auto-escala centrada
        def autoscale_center(ax, x, y, pad_x=0.05, pad_y=0.1):
            if x.size==0 or y.size==0: return
            import numpy as _np
            xmin, xmax = _np.nanmin(x), _np.nanmax(x)
            ymin, ymax = _np.nanmin(y), _np.nanmax(y)
            if not _np.isfinite([xmin,xmax,ymin,ymax]).all(): return
            xr = xmax - xmin; yr = ymax - ymin
            if xr <= 0: xr = 10
            if yr <= 0: yr = 10
            ax.set_xlim(xmin - xr*pad_x, xmax + xr*pad_x)
            ax.set_ylim(ymin - yr*pad_y, ymax + yr*pad_y)

        autoscale_center(ax1, t_arr if t_pred.size==0 else _np.concatenate([t_arr, t_pred]), 
                              _np.concatenate([_np.nan_to_num(et_arr, nan=_np.nanmean(et_arr) if et_arr.size else 0),
                                              _np.nan_to_num(bt_arr, nan=_np.nanmean(bt_arr) if bt_arr.size else 0),
                                              bt_t]))
        autoscale_center(ax2, t_arr, _np.concatenate([_np.nan_to_num(ror_arr, nan=0), ror_t]))

        count_var.set(f"Muestras: {len(S.samples)}")

        # ETA y sugerencias contra objetivos
        def eta_str(s): 
            if s is None: return "—"
            return f"{int(s//60)}m{int(s%60)}s"
        try:
            eta1.config(text="ETA 1C: "+eta_str(S.model.eta_seconds(firstC)))
            etad.config(text="ETA Drop: "+eta_str(S.model.eta_seconds(dropBT)))
        except Exception as e:
            log("ETA error: "+str(e))
        try:
            ror_now = ror_arr[-1] if ror_arr.size else None
            ror_target_now = ror_t[-1] if ror_t.size else 7.0
            sugg.config(text="Sugerencia: "+gas_air_suggestion(ror_now, ror_target_now))
        except Exception as e:
            log("Sugerencia error: "+str(e))

        canvas.draw_idle()
    except Exception as e:
        log("Loop error: "+str(e)+"\\n"+traceback.format_exc())

# ======= UTILIDADES =======
def wizard_one_point():
    val = simpledialog.askfloat("1 punto (offset)","Ingresa temperatura real (°C) ahora")
    if val is None: return
    raw = S.reader.raw_c
    try: raw = float(raw)
    except: messagebox.showerror("1 punto","Lectura RAW inválida"); return
    CFG["scale_pct"]=100.0
    CFG["offset_c"]=val - raw
    json.dump(CFG, open("config.json","w",encoding="utf-8"), indent=2)
    messagebox.showinfo("1 punto","Aplicado: offset={:.2f}°C".format(CFG["offset_c"]))

def wizard_two_points():
    messagebox.showinfo("2 puntos","Necesitas 0°C (hielo) y ~100°C (ebullición). Sigue las instrucciones.")
    r1 = simpledialog.askfloat("2 puntos","Temp real P1 (°C): ej. 0")
    if r1 is None: return
    messagebox.showinfo("2 puntos","Coloca la punta en P1, espera 10 s y pulsa OK")
    raw1 = S.reader.raw_c
    r2 = simpledialog.askfloat("2 puntos","Temp real P2 (°C): ej. 100")
    if r2 is None: return
    messagebox.showinfo("2 puntos","Coloca la punta en P2, espera 10 s y pulsa OK")
    raw2 = S.reader.raw_c
    try: raw1=float(raw1); raw2=float(raw2)
    except: messagebox.showerror("2 puntos","Lecturas inválidas"); return
    if raw2-raw1 == 0:
        messagebox.showerror("2 puntos","Lecturas idénticas"); return
    scale = (r2 - r1) / (raw2 - raw1)
    offset = r1 - scale*raw1
    CFG["scale_pct"]=scale*100.0; CFG["offset_c"]=offset
    json.dump(CFG, open("config.json","w",encoding="utf-8"), indent=2)
    messagebox.showinfo("2 puntos","Aplicado: scale={:.2f}%, offset={:.2f}°C".format(CFG["scale_pct"], CFG["offset_c"]))

# ======= TIMER =======
S.reader.start()
ani=FuncAnimation(plt.gcf(), animate, interval=int(1000/CFG["sample_hz"]))

def on_close():
    try: S.reader.stop()
    except: pass
    root.destroy()

root.protocol("WM_DELETE_WINDOW", on_close)

def add_event(n):
    log_event(n)
    add_event_to_list(S.events[-1])

# Hook buttons to list
for child in btns.winfo_children():
    if isinstance(child, ttk.Button) and child['text'] in ["CHARGE","TP","DRY_END","1C","2C","DROP"]:
        child.configure(command=lambda n=child['text']: add_event(n))

def redraw_empty():
    # redefine to also limpiar lista eventos
    try:
        while events_list.size():
            events_list.delete(0)
    except: pass
    # limpiar trazas
    for ax in (ax1,ax2):
        ax.cla()
    # Re-crear estilos y leyendas
    ax1.set_title("Temperaturas (ET, BT_est, Set, BT_objetivo, BT_pred)", color=FG)
    ax1.set_ylabel("°C", color=FG)
    ax2.set_title("RoR (actual vs objetivo)", color=FG)
    ax2.set_xlabel("Tiempo (s)", color=FG)
    ax2.set_ylabel("°C/min", color=FG)
    canvas.draw_idle()

# =========== LOOP =========
root.mainloop()
