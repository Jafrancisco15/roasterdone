import numpy as np
import math

class RoastModel:
    def __init__(self, alpha=0.12, ror_window=9):
        self.alpha=float(alpha); self.bt_est=None
        self.t_hist=[]; self.et_hist=[]; self.bt_hist=[]; self.ror_hist=[]
        self._w = max(5, (int(ror_window)//2)*2+1)

    def step(self, t, et):
        if self.bt_est is None:
            self.bt_est = et*0.85
        else:
            self.bt_est = self.bt_est + self.alpha*(et - self.bt_est)
        self.t_hist.append(t); self.et_hist.append(et); self.bt_hist.append(self.bt_est)
        ror = math.nan
        if len(self.bt_hist)>=3:
            ror = (self.bt_hist[-1]-self.bt_hist[-3])/(self.t_hist[-1]-self.t_hist[-3]+1e-6)*60.0
        self.ror_hist.append(ror)
        if len(self.ror_hist)>=self._w:
            self.ror_hist[-1] = float(np.nanmean(self.ror_hist[-self._w:]))
        return self.bt_est, self.ror_hist[-1]

    def reset(self):
        self.bt_est=None; self.t_hist.clear(); self.et_hist.clear(); self.bt_hist.clear(); self.ror_hist.clear()

    def eta_seconds(self, target_bt):
        N = min(20, len(self.bt_hist))
        if N < 4: 
            return None
        y = np.array(self.bt_hist[-N:])
        x = np.array(self.t_hist[-N:])
        A = np.vstack([x, np.ones_like(x)]).T
        try:
            a,b = np.linalg.lstsq(A, y, rcond=None)[0]
        except Exception:
            return None
        if abs(a) < 1e-6:
            return None
        t_hit = (target_bt - b) / a
        t_now = self.t_hist[-1]
        eta = t_hit - t_now
        if eta < 0 or eta > 3600:
            return None
        return float(eta)

def gas_air_suggestion(ror_now, ror_target, tol=0.4):
    import math
    if ror_now is None or (isinstance(ror_now,float) and math.isnan(ror_now)): return "—"
    if ror_now>ror_target+tol: return "Bajar GAS 1; revisar AIRE +1"
    if ror_now<ror_target-tol: return "Subir GAS 1; revisar AIRE -1"
    return "Mantener"

def target_profile_curve(t_sec, firstC=196.0, drop=205.0, total_t=720.0, ror_start=12.0, ror_end=3.0):
    """Devuelve BT_target y RoR_target para un tiempo t en segundos.
    RoR_target decrece suavemente de ror_start a ror_end. BT_target es la integral.
    """
    k = 0.0025  # decaimiento
    ror_t = ror_end + (ror_start - ror_end)*math.exp(-k*t_sec)
    ambient = 25.0
    bt_t = ambient + (ror_end*(t_sec/60.0)) + ((ror_start-ror_end)*(1.0 - math.exp(-k*t_sec)) / (k*60.0))
    return bt_t, ror_t
