\
import os, time, json, tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation

from phidget_reader import ETReader
from model import RoastModel, gas_air_suggestion
from storage import export_session_csv, timestamp_slug

BG="#0b0f14"; FG="#e5e7eb"; GLASS="#1a2029"

class S:
    running=False; t0=None
    samples=[]; events=[]; gas=5; air=5; set_temp=0
    meta={"origin":"","density":"","moisture":"","charge_mass_g":"","process":"lavado","brewTarget":"espresso"}
    reader=None; model=None
    ch=0; tc="K"; serial=None; hub=None
S.reader = ETReader(sample_hz=2.0, channel=S.ch, thermocouple_type=S.tc, serial=S.serial, hub_port=S.hub)
S.model = RoastModel(alpha=0.12)

def style_root(root):
    root.title("RoastLab Python")
    root.configure(bg=BG)
    st=ttk.Style(root); st.theme_use("clam")
    st.configure("TLabel", background=BG, foreground=FG)
    st.configure("TFrame", background=BG)
    st.configure("TButton", background=GLASS, foreground=FG, borderwidth=0)
    st.map("TButton", background=[('active','#222a34')])

root=tk.Tk(); style_root(root)

top=ttk.Frame(root); top.pack(fill="x", padx=10, pady=6)
status=tk.Canvas(top,width=16,height=16,highlightthickness=0,bg=BG); status.pack(side="left")
DOT=status.create_oval(2,2,14,14,fill="#ef4444",outline="")
ETVAR=tk.StringVar(value="ET —.— °C"); ttk.Label(top,textvariable=ETVAR,font=("Segoe UI",18,"bold")).pack(side="left",padx=10)

ttk.Label(top,text="Canal").pack(side="left",padx=(8,4))
spin_ch=ttk.Spinbox(top,from_=0,to=3,width=4); spin_ch.set(S.ch); spin_ch.pack(side="left")
ttk.Label(top,text="TC").pack(side="left",padx=(8,4))
tc=ttk.Combobox(top, values=["K","J","E","T","N","S","R","B"], width=4); tc.set(S.tc); tc.pack(side="left")
ttk.Label(top,text="Serial").pack(side="left",padx=(8,4)); ent_serial=ttk.Entry(top,width=10); ent_serial.pack(side="left")
ttk.Label(top,text="Hub").pack(side="left",padx=(8,4)); ent_hub=ttk.Entry(top,width=5); ent_hub.pack(side="left")

proc=ttk.Combobox(top, values=["natural","honey","anaerobico","levadura","lavado"], width=12); proc.set(S.meta["process"]); proc.pack(side="left", padx=(12,0))
brew=ttk.Combobox(top, values=["espresso","filter","both"], width=10); brew.set(S.meta["brewTarget"]); brew.pack(side="left")
ttk.Label(top,text="Gas").pack(side="left",padx=(12,4)); gas=ttk.Spinbox(top,from_=1,to=10,width=4); gas.set(S.gas); gas.pack(side="left")
ttk.Label(top,text="Aire").pack(side="left",padx=(8,4)); air=ttk.Spinbox(top,from_=1,to=10,width=4); air.set(S.air); air.pack(side="left")
ttk.Label(top,text="Set°").pack(side="left",padx=(8,4)); setv=ttk.Spinbox(top,from_=0,to=300,width=6); setv.set(S.set_temp); setv.pack(side="left")
ttk.Label(top,text="Origen").pack(side="left",padx=(12,4)); origin=ttk.Entry(top,width=16); origin.pack(side="left")
ttk.Label(top,text="Densidad").pack(side="left",padx=(8,4)); density=ttk.Entry(top,width=8); density.pack(side="left")
ttk.Label(top,text="Humedad").pack(side="left",padx=(8,4)); moist=ttk.Entry(top,width=6); moist.pack(side="left")

btns=ttk.Frame(root); btns.pack(fill="x", padx=10, pady=6)
def log_event(n):
    t=0.0 if not S.t0 else time.time()-S.t0
    bt=S.model.bt_hist[-1] if S.model.bt_hist else None
    et=S.model.et_hist[-1] if S.model.et_hist else None
    S.events.append({"event":n,"t_sec":round(t,2),"temp_c":round((bt or et or 0),1)})
    messagebox.showinfo("Evento", f"{n} @ {t:.1f}s")
for name in ["CHARGE","TP","DRY_END","1C","2C","DROP"]:
    ttk.Button(btns, text=name, command=lambda n=name: log_event(n)).pack(side="left", padx=4)
def export_all():
    if not S.samples: messagebox.showwarning("Export","No hay muestras"); return
    base=filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"roast-{timestamp_slug()}")
    if not base: return
    meta=S.meta|{"events_count":len(S.events)}
    fig.savefig(base.replace(".csv","")+".plot.png", dpi=140, facecolor=BG)
    from storage import export_session_csv
    export_session_csv(base, S.samples, S.events, meta)
    messagebox.showinfo("Export","CSV/PNG exportados.")
ttk.Button(btns, text="Export CSV/PNG", command=export_all).pack(side="right", padx=4)

ctrl=ttk.Frame(root); ctrl.pack(fill="x", padx=10, pady=6)
def apply_device():
    try:
        S.ch=int(spin_ch.get()); S.tc=tc.get().strip().upper()
        S.serial=int(ent_serial.get()) if ent_serial.get().strip() else None
        S.hub=int(ent_hub.get()) if ent_hub.get().strip() else None
        try: S.reader.stop()
        except: pass
        S.reader = ETReader(sample_hz=2.0, channel=S.ch, thermocouple_type=S.tc, serial=S.serial, hub_port=S.hub)
        S.reader.start()
        messagebox.showinfo("Phidget", f"Reiniciado: canal {S.ch}, TC {S.tc}")
    except Exception as e:
        messagebox.showerror("Phidget", f"No se pudo aplicar: {e}")
ttk.Button(ctrl,text="Aplicar Phidget", command=apply_device).pack(side="left", padx=4)

def start_run():
    if not S.running:
        S.running=True
        if S.t0 is None: S.t0=time.time()
def pause_run():
    S.running=False
def stop_all():
    try: S.reader.stop()
    except: pass
    root.destroy()
ttk.Button(ctrl,text="Start", command=start_run).pack(side="left", padx=4)
ttk.Button(ctrl,text="Pause", command=pause_run).pack(side="left", padx=4)
ttk.Button(ctrl,text="Stop (Cerrar)", command=stop_all).pack(side="right", padx=4)

footer=ttk.Frame(root); footer.pack(fill="x", padx=10, pady=4)
eta1=ttk.Label(footer,text="ETA 1C: —"); eta1.pack(side="left",padx=8)
etad=ttk.Label(footer,text="ETA Drop: —"); etad.pack(side="left",padx=8)
sugg=ttk.Label(footer,text="Sugerencia: —"); sugg.pack(side="left",padx=8)

fig,(ax1,ax2)=plt.subplots(2,1,figsize=(9,6),dpi=100)
fig.patch.set_facecolor(BG)
for ax in (ax1,ax2):
    ax.set_facecolor(BG); ax.tick_params(colors=FG)
    for sp in ax.spines.values(): sp.set_color("#1f2937")
    ax.grid(True,color="#223041",alpha=0.25)
ln_et,=ax1.plot([],[],label="ET",color="#60a5fa")
ln_bt,=ax1.plot([],[],label="BT_est",color="#f59e0b")
ln_set,=ax1.plot([],[],label="Set",color="#94a3b8",linestyle="--")
ax1.legend(facecolor=BG, labelcolor=FG, edgecolor="#1f2937", loc="upper left")
ln_ror,=ax2.plot([],[],label="RoR",color="#a3e635")
ln_ror_t,=ax2.plot([],[],label="RoR target",color="#ef4444",linestyle="--")
ax2.legend(facecolor=BG, labelcolor=FG, edgecolor="#1f2937", loc="upper left")
canvas=FigureCanvasTkAgg(fig, master=root); canvas.get_tk_widget().pack(fill="both",expand=True,padx=10,pady=6)

def push_meta(*_):
    S.meta["process"]=proc.get(); S.meta["brewTarget"]=brew.get()
    try: S.gas=int(gas.get()); S.air=int(air.get()); S.set_temp=int(setv.get())
    except: pass
    S.meta["origin"]=origin.get(); S.meta["density"]=density.get(); S.meta["moisture"]=moist.get()
for w in [proc,brew,gas,air,setv,origin,density,moist]:
    if hasattr(w,"bind"): w.bind("<<ComboboxSelected>>", push_meta)

S.reader.start()  # auto-start: ET siempre en vivo

def animate(_):
    et=S.reader.et_c; ok=S.reader.ok
    status.itemconfig(DOT, fill=("#22c55e" if ok else "#ef4444"))
    ETVAR.set(f"ET {et:.1f} °C" if et==et else "ET —.— °C")

    now=time.time()
    if S.t0 is None: S.t0=now
    t=now-S.t0

    if not S.samples:
        S.samples.append({"t_sec":0.0,"et_c":et if et==et else np.nan,"bt_est_c":np.nan,"ror":np.nan,"gas":S.gas,"air":S.air,"set_temp":S.set_temp})
    else:
        if S.running:
            bt, ror = S.model.step(t, et if et==et else (S.model.bt_hist[-1] if S.model.bt_hist else np.nan))
            try:
                prof=json.load(open("profiles.json","r",encoding="utf-8"))[S.meta["process"]][S.meta["brewTarget"]]
                S.model.alpha=float(prof["alpha"]); ror_target=float(prof["rorTarget"])
                firstC=float(prof["firstCrackBT"]); dropBT=float(prof["dropBT"])
            except Exception:
                ror_target=7.0; firstC=196.0; dropBT=205.0
            S.samples.append({"t_sec":round(t,2),"et_c":round(et,2) if et==et else np.nan,"bt_est_c":round(bt,2),"ror":round(ror if isinstance(ror,float) else 0.0,3),"gas":S.gas,"air":S.air,"set_temp":S.set_temp})
            def eta_str(s): 
                if s is None: return "—"
                return f"{int(s//60)}m{int(s%60)}s"
            eta1.config(text="ETA 1C: "+eta_str(S.model.eta_seconds(firstC)))
            etad.config(text="ETA Drop: "+eta_str(S.model.eta_seconds(dropBT)))
            sugg.config(text="Sugerencia: "+gas_air_suggestion(ror if isinstance(ror,float) else None, ror_target))
        else:
            last=S.samples[-1]; last["et_c"]=round(et,2) if et==et else np.nan

    t_arr=[s["t_sec"] for s in S.samples]
    et_arr=[s["et_c"] for s in S.samples]
    bt_arr=[s.get("bt_est_c",np.nan) for s in S.samples]
    ror_arr=[s.get("ror",np.nan) for s in S.samples]

    ror_target = 7.0
    try:
        prof=json.load(open("profiles.json","r",encoding="utf-8"))[S.meta["process"]][S.meta["brewTarget"]]
        ror_target=float(prof["rorTarget"])
    except Exception:
        pass

    ln_et.set_data(t_arr, et_arr); ln_bt.set_data(t_arr, bt_arr); ln_set.set_data(t_arr, [S.set_temp]*len(t_arr))
    ln_ror.set_data(t_arr, ror_arr); ln_ror_t.set_data(t_arr, [ror_target]*len(t_arr))
    for ax in (ax1,ax2):
        ax.relim(); ax.autoscale_view()

ani=FuncAnimation(fig, animate, interval=500)
root.protocol("WM_DELETE_WINDOW", lambda: (S.reader.stop(), root.destroy()))
root.mainloop()
