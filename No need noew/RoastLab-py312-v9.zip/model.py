import math
import numpy as np

class RoastModel:
    def __init__(self, kappa=0.06, ror_window=9):
        self.kappa = float(kappa)
        self.bt_est = None
        self.t_prev = None
        self.t_hist=[]; self.et_hist=[]; self.bt_hist=[]; self.ror_hist=[]
        self._w = max(5, (int(ror_window)//2)*2+1)

    def step(self, t, et):
        if self.t_prev is None:
            self.t_prev = t
        dt = max(1e-3, t - self.t_prev)
        self.t_prev = t

        if self.bt_est is None:
            self.bt_est = et * 0.85
        else:
            self.bt_est = self.bt_est + self.kappa * (et - self.bt_est) * dt

        self.t_hist.append(t); self.et_hist.append(et); self.bt_hist.append(self.bt_est)

        ror = math.nan
        if len(self.bt_hist) >= 3:
            ror = (self.bt_hist[-1] - self.bt_hist[-3]) / (self.t_hist[-1] - self.t_hist[-3] + 1e-6) * 60.0
        self.ror_hist.append(ror)

        if len(self.ror_hist) >= self._w:
            w = [x for x in self.ror_hist[-self._w:] if x == x]
            if w:
                self.ror_hist[-1] = sum(w)/len(w)
        return self.bt_est, self.ror_hist[-1]

    def reset(self):
        self.bt_est=None; self.t_prev=None
        self.t_hist.clear(); self.et_hist.clear(); self.bt_hist.clear(); self.ror_hist.clear()

    def eta_seconds(self, target_bt):
        if len(self.bt_hist) < 4:
            return None
        N = min(20, len(self.bt_hist))
        y = np.array(self.bt_hist[-N:])
        x = np.array(self.t_hist[-N:])
        A = np.vstack([x, np.ones_like(x)]).T
        try:
            a,b = np.linalg.lstsq(A, y, rcond=None)[0]
        except Exception:
            return None
        if abs(a) < 1e-6: return None
        t_hit = (target_bt - b)/a
        eta = t_hit - x[-1]
        return None if eta < 0 or eta > 3600 else float(eta)

def gas_air_suggestion(ror_now, ror_target, tol=0.4):
    if ror_now is None or (isinstance(ror_now,float) and math.isnan(ror_now)): return "—"
    if ror_now > ror_target + tol: return "Bajar GAS 1; revisar AIRE +1"
    if ror_now < ror_target - tol: return "Subir GAS 1; revisar AIRE -1"
    return "Mantener"

def target_profile_curve(t_sec, firstC=196.0, drop=205.0, total_t=720.0, ror_start=12.0, ror_end=3.0):
    k = 0.0025
    ror_t = ror_end + (ror_start - ror_end)*math.exp(-k*t_sec)
    ambient = 25.0
    bt_t = ambient + (ror_end*(t_sec/60.0)) + ((ror_start-ror_end)*(1.0 - math.exp(-k*t_sec)) / (k*60.0))
    return bt_t, ror_t
