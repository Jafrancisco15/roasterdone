RoastLab v9 (Python 3.12)
---------------------------------
1) Doble click: run312.bat
2) Phidgets drivers si usas 1048.
3) Canal=0, TC=K, Simulador OFF, Entrada °F→°C OFF (1048 ya da °C)
4) Start / Stop / Reset, Test lectura, Export CSV/PNG
5) BT_est: modelo 1er orden (kappa=0.06). Ajusta en model.py.
