import time, threading, math, random, collections

class ETReader:
    """Reads Exhaust Temp (ET) from Phidget 1048, default channel=0, Type K.
       Falls back to simulator if hardware not present, or if force_sim=True.
       Includes basic drift guard and smoothing."""
    def __init__(self, sample_hz=2.0, channel=0, thermocouple_type="K", force_sim=False):
        self.sample_dt = 1.0 / max(0.1, sample_hz)
        self.et_c = float('nan')
        self.ok = False
        self._stop = threading.Event()
        self._use_sim = force_sim
        self.channel = int(channel)
        self.thermocouple_type = str(thermocouple_type).upper()
        self._dq = collections.deque(maxlen=7)  # mediana móvil

        if not self._use_sim:
            try:
                from Phidget22.Devices.TemperatureSensor import TemperatureSensor
                from Phidget22.ThermocoupleType import ThermocoupleType
                self._ts = TemperatureSensor()
                self._ts.setChannel(self.channel)
                self._ts.openWaitForAttachment(5000)
                tc_map = {
                    "K": ThermocoupleType.THERMOCOUPLE_TYPE_K,
                    "J": ThermocoupleType.THERMOCOUPLE_TYPE_J,
                    "E": ThermocoupleType.THERMOCOUPLE_TYPE_E,
                    "T": ThermocoupleType.THERMOCOUPLE_TYPE_T,
                    "N": ThermocoupleType.THERMOCOUPLE_TYPE_N,
                    "S": ThermocoupleType.THERMOCOUPLE_TYPE_S,
                    "R": ThermocoupleType.THERMOCOUPLE_TYPE_R,
                    "B": ThermocoupleType.THERMOCOUPLE_TYPE_B,
                }
                try:
                    self._ts.setThermocoupleType(tc_map.get(self.thermocouple_type, ThermocoupleType.THERMOCOUPLE_TYPE_K))
                except Exception:
                    pass
                try:
                    self._ts.setTemperatureChangeTrigger(0.0)
                except Exception:
                    pass
                try:
                    self._ts.setDataInterval(500)
                except Exception:
                    pass
                self.ok = True
            except Exception:
                self._use_sim = True
                self.ok = False

        self._thread = threading.Thread(target=self._loop, daemon=True)

    def start(self):
        self._stop.clear()
        if not self._thread.is_alive():
            self._thread = threading.Thread(target=self._loop, daemon=True)
            self._thread.start()

    def stop(self):
        self._stop.set()
        try:
            if not self._use_sim:
                self._ts.close()
        except Exception:
            pass

    def _smooth(self, val):
        import statistics
        self._dq.append(val)
        try:
            return statistics.median(self._dq)
        except Exception:
            return val

    def _loop(self):
        t_prev = None
        last_val = None
        while not self._stop.is_set():
            if self._use_sim:
                t_prev = (t_prev or 0.0) + self.sample_dt
                base = 24 + 100 * (1 - math.exp(-t_prev/140.0))
                ripple = 0.4 * math.sin(t_prev/5.0) + 0.15 * math.sin(t_prev/1.7)
                raw = base + ripple
                self.et_c = self._smooth(raw)
                self.ok = False
            else:
                try:
                    raw = self._ts.getTemperature()  # Celsius
                    # Clamp rango plausible
                    if raw < -10 or raw > 350:
                        raw = float('nan')
                    # Limitar pendientes absurdas si máquina "apagada"
                    if last_val is not None:
                        dv = raw - last_val
                        if abs(dv) > 2.0:  # >2C por tick de 0.5s = >4C/s (muy raro en reposo)
                            raw = last_val + (2.0 if dv>0 else -2.0)
                    last_val = raw
                    self.et_c = self._smooth(raw)
                    self.ok = True
                except Exception:
                    self.ok = False
            time.sleep(self.sample_dt)
