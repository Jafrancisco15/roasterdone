\
import os, time, json, tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation

from phidget_reader import ETReader
from model import RoastModel, gas_air_suggestion
from storage import export_session_csv, timestamp_slug

APPNAME="RoastLab"
BG="#0c1118"; FG="#e6edf3"; GLASS="#111827"; GRID="#1f2a37"; ACC="#38bdf8"

class S:
    running=False; t0=None
    samples=[]; events=[]; gas=5; air=5; set_temp=0
    meta={"origin":"","density":"","moisture":"","charge_mass_g":"","process":"lavado","brewTarget":"espresso"}
    reader=None; model=None
    ch=0; tc="K"; serial=None; hub=None
    force_sim=False
    input_is_f=False  # si el sensor estuviera entregando Fahrenheit por error

S.reader = ETReader(sample_hz=2.0, channel=S.ch, thermocouple_type=S.tc, serial=S.serial, hub_port=S.hub, force_sim=S.force_sim)
S.model = RoastModel(alpha=0.12)

def style_root(root):
    root.title(APPNAME)
    root.configure(bg=BG)
    st=ttk.Style(root); st.theme_use("clam")
    st.configure("TLabel", background=BG, foreground=FG, font=("Segoe UI", 10))
    st.configure("TFrame", background=BG)
    st.configure("TButton", background=GLASS, foreground=FG, borderwidth=0, padding=8, font=("Segoe UI Semibold", 10))
    st.map("TButton", background=[('active','#1b2430')])
    st.configure("TEntry", fieldbackground="#0f1621", foreground=FG, insertcolor=FG)
    st.configure("TSpinbox", fieldbackground="#0f1621", foreground=FG, arrowsize=14)
    st.configure("TCombobox", fieldbackground="#0f1621", foreground=FG)
root=tk.Tk(); style_root(root)

# ======= TOP BAR =======
top=ttk.Frame(root); top.pack(fill="x", padx=12, pady=8)
status=tk.Canvas(top,width=14,height=14,highlightthickness=0,bg=BG); status.pack(side="left")
DOT=status.create_oval(1,1,13,13,fill="#ef4444",outline="")
ETVAR=tk.StringVar(value="ET —.— °C"); ttk.Label(top,textvariable=ETVAR,font=("Segoe UI",20,"bold")).pack(side="left",padx=10)

# Device config
ttk.Label(top,text="Canal").pack(side="left",padx=(8,4))
spin_ch=ttk.Spinbox(top,from_=0,to=3,width=4); spin_ch.set(S.ch); spin_ch.pack(side="left")
ttk.Label(top,text="TC").pack(side="left",padx=(8,4))
tc=ttk.Combobox(top, values=["K","J","E","T","N","S","R","B"], width=4); tc.set(S.tc); tc.pack(side="left")
ttk.Label(top,text="Serial").pack(side="left",padx=(8,4)); ent_serial=ttk.Entry(top,width=12); ent_serial.pack(side="left")
ttk.Label(top,text="Hub").pack(side="left",padx=(8,4)); ent_hub=ttk.Entry(top,width=6); ent_hub.pack(side="left")

# Simulator + Units
sim_var=tk.BooleanVar(value=S.force_sim)
chk_sim=ttk.Checkbutton(top, text="Simulador", variable=sim_var, command=lambda: toggle_sim())
chk_sim.pack(side="left", padx=(12,4))
inputf_var=tk.BooleanVar(value=S.input_is_f)
chk_f=ttk.Checkbutton(top, text="Entrada °F→°C", variable=inputf_var)
chk_f.pack(side="left", padx=(6,4))

proc=ttk.Combobox(top, values=["natural","honey","anaerobico","levadura","lavado"], width=12); proc.set(S.meta["process"]); proc.pack(side="left", padx=(12,0))
brew=ttk.Combobox(top, values=["espresso","filter","both"], width=10); brew.set(S.meta["brewTarget"]); brew.pack(side="left")
ttk.Label(top,text="Gas").pack(side="left",padx=(12,4)); gas=ttk.Spinbox(top,from_=1,to=10,width=4); gas.set(S.gas); gas.pack(side="left")
ttk.Label(top,text="Aire").pack(side="left",padx=(8,4)); air=ttk.Spinbox(top,from_=1,to=10,width=4); air.set(S.air); air.pack(side="left")
ttk.Label(top,text="Set°").pack(side="left",padx=(8,4)); setv=ttk.Spinbox(top,from_=0,to=300,width=6); setv.set(S.set_temp); setv.pack(side="left")
ttk.Label(top,text="Origen").pack(side="left",padx=(12,4)); origin=ttk.Entry(top,width=18); origin.pack(side="left")
ttk.Label(top,text="Densidad").pack(side="left",padx=(8,4)); density=ttk.Entry(top,width=10); density.pack(side="left")
ttk.Label(top,text="Humedad").pack(side="left",padx=(8,4)); moist=ttk.Entry(top,width=8); moist.pack(side="left")

def toggle_sim():
    S.force_sim = sim_var.get()
    try: S.reader.stop()
    except: pass
    S.reader = ETReader(sample_hz=2.0, channel=int(spin_ch.get()), thermocouple_type=tc.get(), 
                        serial=(int(ent_serial.get()) if ent_serial.get().strip() else None),
                        hub_port=(int(ent_hub.get()) if ent_hub.get().strip() else None),
                        force_sim=S.force_sim)
    S.reader.start()

# ======= BUTTONS =======
btns=ttk.Frame(root); btns.pack(fill="x", padx=12, pady=8)
def log_event(n):
    t=0.0 if not S.t0 else time.time()-S.t0
    bt=S.model.bt_hist[-1] if S.model.bt_hist else None
    et=S.reader.et_c
    if inputf_var.get() and et==et:  # si la entrada esta en F, convertir a C
        et = (et - 32.0) * 5.0/9.0
    temp = bt if (bt is not None) else et
    S.events.append({"event":n,"t_sec":round(t,2),"temp_c":round(temp,1)})
    # annotate on chart
    annotate_event(n, t, temp)
for name in ["CHARGE","TP","DRY_END","1C","2C","DROP"]:
    ttk.Button(btns, text=name, command=lambda n=name: log_event(n)).pack(side="left", padx=4)
def export_all():
    if not S.samples: messagebox.showwarning("Export","No hay muestras"); return
    base=filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"roast-{timestamp_slug()}")
    if not base: return
    meta=S.meta|{"events_count":len(S.events)}
    fig.savefig(base.replace(".csv","")+".plot.png", dpi=160, facecolor=BG)
    export_session_csv(base, S.samples, S.events, meta)
    messagebox.showinfo("Export","CSV/PNG exportados.")
ttk.Button(btns, text="Export CSV/PNG", command=export_all).pack(side="right", padx=4)

# Control buttons
ctrl=ttk.Frame(root); ctrl.pack(fill="x", padx=12, pady=6)
def apply_device():
    try:
        try: S.reader.stop()
        except: pass
        S.reader = ETReader(sample_hz=2.0, channel=int(spin_ch.get()), thermocouple_type=tc.get(),
                            serial=(int(ent_serial.get()) if ent_serial.get().strip() else None),
                            hub_port=(int(ent_hub.get()) if ent_hub.get().strip() else None),
                            force_sim=sim_var.get())
        S.reader.start()
        messagebox.showinfo("Phidget", f"Aplicado: canal {spin_ch.get()}, TC {tc.get()}")
    except Exception as e:
        messagebox.showerror("Phidget", f"No se pudo aplicar: {e}")
ttk.Button(ctrl,text="Start", command=lambda: start_run()).pack(side="left", padx=4)
ttk.Button(ctrl,text="Pause", command=lambda: pause_run()).pack(side="left", padx=4)
ttk.Button(ctrl,text="Stop (Cerrar)", command=lambda: stop_all()).pack(side="right", padx=4)
ttk.Button(ctrl,text="Aplicar Phidget", command=apply_device).pack(side="right", padx=8)

footer=ttk.Frame(root); footer.pack(fill="x", padx=12, pady=4)
eta1=ttk.Label(footer,text="ETA 1C: —"); eta1.pack(side="left",padx=8)
etad=ttk.Label(footer,text="ETA Drop: —"); etad.pack(side="left",padx=8)
sugg=ttk.Label(footer,text="Sugerencia: —"); sugg.pack(side="left",padx=8)

# ======= PLOTS =======
plt.rcParams.update({
    "axes.titlesize": 12, "axes.labelsize": 11, "xtick.labelsize": 10, "ytick.labelsize": 10,
    "font.family": "Segoe UI",
})
fig,(ax1,ax2)=plt.subplots(2,1,figsize=(10.5,7.0),dpi=110)
fig.patch.set_facecolor(BG)
for ax in (ax1,ax2):
    ax.set_facecolor(BG); ax.tick_params(colors=FG,labelsize=10)
    for sp in ax.spines.values(): sp.set_color(GRID)
    ax.grid(True,color=GRID,alpha=0.35,linewidth=0.7)
ax1.set_title("Temperaturas"); ax2.set_title("Rate of Rise (RoR)")
ln_et,=ax1.plot([],[],label="ET",linewidth=2.2,color="#60a5fa")
ln_bt,=ax1.plot([],[],label="BT_est",linewidth=2.2,color="#f59e0b")
ln_set,=ax1.plot([],[],label="Set",linewidth=1.6,color="#94a3b8",linestyle="--")
ax1.legend(facecolor=BG, labelcolor=FG, edgecolor=GRID, loc="upper left")
ln_ror,=ax2.plot([],[],label="RoR",linewidth=2.0,color="#a3e635")
ln_ror_t,=ax2.plot([],[],label="RoR target",linewidth=1.6,color="#ef4444",linestyle="--")
ax2.legend(facecolor=BG, labelcolor=FG, edgecolor=GRID, loc="upper left")
canvas=FigureCanvasTkAgg(fig, master=root); canvas.get_tk_widget().pack(fill="both",expand=True,padx=12,pady=8)

# annotations store
event_artists=[]

def annotate_event(name, t, temp_c):
    # Vertical line + text bubble
    v=ax1.axvline(t, color="#f87171", linestyle="--", linewidth=1.2, alpha=0.9)
    marker=ax1.plot(t, temp_c, marker="o", color="#f87171", markersize=5)[0]
    text=ax1.text(t, temp_c+3, f"{name}\\n{t:.0f}s @ {temp_c:.1f}°C", color=FG,
                  bbox=dict(boxstyle="round,pad=0.3", fc=GLASS, ec=GRID, alpha=0.9),
                  ha="left", va="bottom", fontsize=9)
    event_artists.append((v,marker,text))

def start_run():
    if not S.running:
        S.running=True
        if S.t0 is None: S.t0=time.time()
def pause_run():
    S.running=False
def stop_all():
    try: S.reader.stop()
    except: pass
    root.destroy()

def push_meta(*_):
    S.meta["process"]=proc.get(); S.meta["brewTarget"]=brew.get()
    try: S.gas=int(gas.get()); S.air=int(air.get()); S.set_temp=int(setv.get())
    except: pass
    S.meta["origin"]=origin.get(); S.meta["density"]=density.get(); S.meta["moisture"]=moist.get()
for w in [proc,brew,gas,air,setv,origin,density,moist]:
    if hasattr(w,"bind"): w.bind("<<ComboboxSelected>>", push_meta)

# Auto-start reader so ET is always live
S.reader.start()

def animate(_):
    et=S.reader.et_c; ok=S.reader.ok
    # Si el usuario indica que la entrada es Fahrenheit, convertimos a C para usar internamente
    if et==et and inputf_var.get():
        et = (et - 32.0) * (5.0/9.0)
    status.itemconfig(DOT, fill=("#22c55e" if ok else "#ef4444"))
    ETVAR.set(f"ET {et:.1f} °C" if et==et else "ET —.— °C")

    now=time.time()
    if S.t0 is None: S.t0=now
    t=now-S.t0

    if not S.samples:
        S.samples.append({"t_sec":0.0,"et_c":et if et==et else np.nan,"bt_est_c":np.nan,"ror":np.nan,"gas":S.gas,"air":S.air,"set_temp":S.set_temp})
    else:
        if S.running:
            bt, ror = S.model.step(t, et if et==et else (S.model.bt_hist[-1] if S.model.bt_hist else np.nan))
            try:
                prof=json.load(open("profiles.json","r",encoding="utf-8"))[S.meta["process"]][S.meta["brewTarget"]]
                S.model.alpha=float(prof["alpha"]); ror_target=float(prof["rorTarget"])
                firstC=float(prof["firstCrackBT"]); dropBT=float(prof["dropBT"])
            except Exception:
                ror_target=7.0; firstC=196.0; dropBT=205.0
            S.samples.append({"t_sec":round(t,2),"et_c":round(et,2) if et==et else np.nan,"bt_est_c":round(bt,2),"ror":round(ror if isinstance(ror,float) else 0.0,3),"gas":S.gas,"air":S.air,"set_temp":S.set_temp})
            # ETAs y sugerencias
            def eta_str(s): 
                if s is None: return "—"
                return f"{int(s//60)}m{int(s%60)}s"
            eta1.config(text="ETA 1C: "+eta_str(S.model.eta_seconds(firstC)))
            etad.config(text="ETA Drop: "+eta_str(S.model.eta_seconds(dropBT)))
            sugg.config(text="Sugerencia: "+gas_air_suggestion(ror if isinstance(ror,float) else None, ror_target))
        else:
            last=S.samples[-1]; last["et_c"]=round(et,2) if et==et else np.nan

    t_arr=[s["t_sec"] for s in S.samples]
    et_arr=[s["et_c"] for s in S.samples]
    bt_arr=[s.get("bt_est_c",np.nan) for s in S.samples]
    ror_arr=[s.get("ror",np.nan) for s in S.samples]

    ror_target = 7.0
    try:
        prof=json.load(open("profiles.json","r",encoding="utf-8"))[S.meta["process"]][S.meta["brewTarget"]]
        ror_target=float(prof["rorTarget"])
    except Exception:
        pass

    ln_et.set_data(t_arr, et_arr); ln_bt.set_data(t_arr, bt_arr); ln_set.set_data(t_arr, [S.set_temp]*len(t_arr))
    ln_ror.set_data(t_arr, ror_arr); ln_ror_t.set_data(t_arr, [ror_target]*len(t_arr))
    for ax in (ax1,ax2):
        ax.relim(); ax.autoscale_view()

ani=FuncAnimation(fig, animate, interval=500)
root.protocol("WM_DELETE_WINDOW", lambda: (S.reader.stop(), root.destroy()))
root.mainloop()
