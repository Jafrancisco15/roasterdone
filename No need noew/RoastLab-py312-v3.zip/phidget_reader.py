import time, threading, math, random

class ETReader:
    """Reads Exhaust Temp (ET) from Phidget 1048, default channel=0, Type K.
       Falls back to simulator if hardware not present, or if force_sim=True."""
    def __init__(self, sample_hz=2.0, channel=0, thermocouple_type="K",
                 serial=None, hub_port=None, force_sim=False):
        self.sample_dt = 1.0 / max(0.1, sample_hz)
        self.et_c = float('nan')
        self.ok = False
        self._stop = threading.Event()
        self._use_sim = force_sim
        self.channel = int(channel)
        self.thermocouple_type = str(thermocouple_type).upper()
        self.serial = serial
        self.hub_port = hub_port

        if not self._use_sim:
            try:
                from Phidget22.Devices.TemperatureSensor import TemperatureSensor
                from Phidget22.ThermocoupleType import ThermocoupleType
                self._ts = TemperatureSensor()
                if self.serial is not None:
                    self._ts.setDeviceSerialNumber(int(self.serial))
                if self.hub_port is not None:
                    self._ts.setHubPort(int(self.hub_port))
                self._ts.setChannel(self.channel)
                self._ts.openWaitForAttachment(5000)
                tc_map = {
                    "K": ThermocoupleType.THERMOCOUPLE_TYPE_K,
                    "J": ThermocoupleType.THERMOCOUPLE_TYPE_J,
                    "E": ThermocoupleType.THERMOCOUPLE_TYPE_E,
                    "T": ThermocoupleType.THERMOCOUPLE_TYPE_T,
                    "N": ThermocoupleType.THERMOCOUPLE_TYPE_N,
                    "S": ThermocoupleType.THERMOCOUPLE_TYPE_S,
                    "R": ThermocoupleType.THERMOCOUPLE_TYPE_R,
                    "B": ThermocoupleType.THERMOCOUPLE_TYPE_B,
                }
                try:
                    self._ts.setThermocoupleType(tc_map.get(self.thermocouple_type, ThermocoupleType.THERMOCOUPLE_TYPE_K))
                except Exception:
                    pass
                try:
                    self._ts.setTemperatureChangeTrigger(0.0)
                except Exception:
                    pass
                try:
                    self._ts.setDataInterval(500)
                except Exception:
                    pass
                self.ok = True
            except Exception:
                self._use_sim = True
                self.ok = False

        self._thread = threading.Thread(target=self._loop, daemon=True)

    def start(self):
        self._thread.start()

    def stop(self):
        self._stop.set()
        try:
            if not self._use_sim:
                self._ts.close()
        except Exception:
            pass

    def _loop(self):
        t0 = time.time()
        while not self._stop.is_set():
            if self._use_sim:
                t = time.time() - t0
                # Simula un perfil de tueste con control suave
                base = 25 + 125 * (1 - math.exp(-t/180.0))  # arranca 25C -> sube ~150C
                ripple = 0.7 * math.sin(t/5.0) + 0.2 * math.sin(t/1.7)
                self.et_c = base + ripple
                self.ok = False
            else:
                try:
                    # Phidget TemperatureSensor devuelve CELSIUS
                    self.et_c = self._ts.getTemperature()
                    self.ok = True
                except Exception:
                    self.ok = False
            time.sleep(self.sample_dt)
