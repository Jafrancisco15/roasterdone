import numpy as np

class RoastModel:
    def __init__(self, alpha=0.12, ror_window=9):
        self.alpha=float(alpha); self.bt_est=None
        self.t_hist=[]; self.et_hist=[]; self.bt_hist=[]; self.ror_hist=[]
        self._w = max(5, (int(ror_window)//2)*2+1)

    def step(self, t, et):
        if self.bt_est is None:
            self.bt_est = et*0.85
        else:
            self.bt_est = self.bt_est + self.alpha*(et - self.bt_est)
        self.t_hist.append(t); self.et_hist.append(et); self.bt_hist.append(self.bt_est)
        ror = np.nan
        if len(self.bt_hist)>=3:
            ror = (self.bt_hist[-1]-self.bt_hist[-3])/(self.t_hist[-1]-self.t_hist[-3]+1e-6)*60.0
        self.ror_hist.append(ror)
        if len(self.ror_hist)>=self._w:
            self.ror_hist[-1] = float(np.nanmean(self.ror_hist[-self._w:]))
        return self.bt_est, self.ror_hist[-1]

    def reset(self):
        self.bt_est=None; self.t_hist.clear(); self.et_hist.clear(); self.bt_hist.clear(); self.ror_hist.clear()

def gas_air_suggestion(ror_now, ror_target, tol=0.4):
    import math
    if ror_now is None or (isinstance(ror_now,float) and math.isnan(ror_now)): return "—"
    if ror_now>ror_target+tol: return "Bajar GAS 1; revisar AIRE +1"
    if ror_now<ror_target-tol: return "Subir GAS 1; revisar AIRE -1"
    return "Mantener"
