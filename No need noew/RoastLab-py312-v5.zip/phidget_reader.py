import time, threading, math, collections

class ETReader:
    """Reads Exhaust Temp (ET) from Phidget 1048, default channel=0, Type K.
       Optional: force_phidget=True -> no simulator fallback, raise on attach failure.
       Includes drift guard and smoothing."""
    def __init__(self, sample_hz=2.0, channel=0, thermocouple_type="K",
                 force_sim=False, force_phidget=False):
        self.sample_dt = 1.0 / max(0.1, sample_hz)
        self.et_c = float('nan')
        self.raw_c = float('nan')
        self.ok = False
        self.source = "Simulador"
        self.warn = ""
        self._stop = threading.Event()
        self._use_sim = force_sim
        self._force_phidget = force_phidget
        self.channel = int(channel)
        self.thermocouple_type = str(thermocouple_type).upper()
        self._dq = collections.deque(maxlen=7)  # mediana móvil
        self._ambient_monitor = collections.deque(maxlen=16)  # ~8s a 0.5s

        self._ts = None
        if not self._use_sim:
            try:
                from Phidget22.Devices.TemperatureSensor import TemperatureSensor
                from Phidget22.ThermocoupleType import ThermocoupleType
                self._ts = TemperatureSensor()
                self._ts.setChannel(self.channel)
                self._ts.openWaitForAttachment(3000)
                tc_map = {
                    "K": ThermocoupleType.THERMOCOUPLE_TYPE_K,
                    "J": ThermocoupleType.THERMOCOUPLE_TYPE_J,
                    "E": ThermocoupleType.THERMOCOUPLE_TYPE_E,
                    "T": ThermocoupleType.THERMOCOUPLE_TYPE_T,
                    "N": ThermocoupleType.THERMOCOUPLE_TYPE_N,
                    "S": ThermocoupleType.THERMOCOUPLE_TYPE_S,
                    "R": ThermocoupleType.THERMOCOUPLE_TYPE_R,
                    "B": ThermocoupleType.THERMOCOUPLE_TYPE_B,
                }
                try: self._ts.setThermocoupleType(tc_map.get(self.thermocouple_type, ThermocoupleType.THERMOCOUPLE_TYPE_K))
                except Exception: pass
                try: self._ts.setTemperatureChangeTrigger(0.0)
                except Exception: pass
                try: self._ts.setDataInterval(500)
                except Exception: pass
                self.ok = True; self.source="Phidget"
            except Exception as e:
                if self._force_phidget:
                    raise
                self._use_sim = True
                self.ok = False; self.source="Simulador"

        self._thread = threading.Thread(target=self._loop, daemon=True)

    def start(self):
        self._stop.clear()
        if not self._thread.is_alive():
            self._thread = threading.Thread(target=self._loop, daemon=True)
            self._thread.start()

    def stop(self):
        self._stop.set()
        try:
            if self._ts is not None:
                self._ts.close()
        except Exception:
            pass

    def _smooth(self, val):
        import statistics
        self._dq.append(val)
        try:
            return statistics.median(self._dq)
        except Exception:
            return val

    def _loop(self):
        last_val = None
        freeze_until = 0.0
        while not self._stop.is_set():
            if self._use_sim:
                t = time.time()
                # rampa leve simulada
                base = 24 + 100 * (1 - math.exp(-(t%9999)/140.0))
                ripple = 0.4 * math.sin(t/5.0) + 0.15 * math.sin(t/1.7)
                raw = base + ripple
                self.raw_c = raw
                self.et_c = self._smooth(raw)
                self.ok = False
            else:
                try:
                    raw = self._ts.getTemperature()  # Celsius
                    self.raw_c = raw
                    # Clamp rango plausible
                    if raw < -10 or raw > 350:
                        raw = float('nan')
                    # Inicializar last_val sin clamp en primera pasada
                    if last_val is None:
                        last_val = raw
                    else:
                        # Limitar pendiente absurda (>4C/s) solo si estamos por debajo de 40C (ambiente)
                        dv = raw - last_val
                        if self._ambient_monitor and max(self._ambient_monitor) < 40.0:
                            if abs(dv) > 2.0:  # 0.5s tick -> 4C/s
                                raw = last_val + (2.0 if dv>0 else -2.0)
                        last_val = raw
                    # Ambient drift guard: si <40C y tendencia >0.5C/s por ~8s, congelar a mediana
                    now = time.time()
                    self._ambient_monitor.append(raw)
                    if len(self._ambient_monitor) >= 8:
                        span = len(self._ambient_monitor) * 0.5  # 0.5s per sample
                        if span >= 4.0:
                            delta = self._ambient_monitor[-1] - self._ambient_monitor[0]
                            slope = delta / span  # C/s
                            if max(self._ambient_monitor) < 40.0 and slope > 0.5 and now > freeze_until:
                                # congela durante 5s a la mediana
                                med = self._smooth(raw)
                                self.et_c = med
                                self.warn = "Drift ambiente detectado: congelando 5s"
                                freeze_until = now + 5.0
                            else:
                                self.warn = ""
                    if now < freeze_until:
                        # mantener congelado
                        pass
                    else:
                        self.et_c = self._smooth(raw)
                    self.ok = True; self.source="Phidget"
                except Exception:
                    self.ok = False; self.source="Phidget?"
            time.sleep(self.sample_dt)
